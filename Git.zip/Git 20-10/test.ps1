# Define variables
$ServerName = "localhost"
$DatabaseName = "devops_demo"  # Specify the database name here
$Username = "root"
$Password = "P@ssw0rd"
$SqlScriptPath = "C:\Users\t\Desktop\devops_sql\test.ps1"

# Step 1: Deploy the Database Schema using MySQL Command-Line
$mysqlOptions = "-h $ServerName -u $Username -p$Password $DatabaseName < $SqlScriptPath"
$mysqlCommand = "mysql $mysqlOptions"

Write-Host "Deploying Database Schema..."
Invoke-Expression -Command $mysqlCommand

Write-Host "Database Deployment Completed!"

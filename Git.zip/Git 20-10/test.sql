-- Script.sql
create database devops_demo;
use devops_demo;
-- Create a table for students
CREATE TABLE IF NOT EXISTS `students` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `roll_no` VARCHAR(20) UNIQUE NOT NULL,
    `branch` VARCHAR(50),
    `full_name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `phone_number` VARCHAR(15)
);

-- Insert sample data
INSERT INTO `students` (`full_name`, `email`, `roll_no`, `branch`, `phone_number`) VALUES
('John Doe', 'john.doe@example.com', 'A12345', 'Computer Science', '+1 (555) 123-4567'),
('Jane Smith', 'jane.smith@example.com', 'B67890', 'Electrical Engineering', '+1 (555) 987-6543');
